/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9965277777777778, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.998015873015873, 500, 1500, "UpdateUser2"], "isController": false}, {"data": [0.996031746031746, 500, 1500, "Loginuser1"], "isController": false}, {"data": [0.998015873015873, 500, 1500, "UpdateUser3"], "isController": false}, {"data": [0.998015873015873, 500, 1500, "Loginuser2"], "isController": false}, {"data": [1.0, 500, 1500, "Loginuser3"], "isController": false}, {"data": [0.9940476190476191, 500, 1500, "UpdateUser1"], "isController": false}, {"data": [0.9990079365079365, 500, 1500, "ApplyLoan1"], "isController": false}, {"data": [1.0, 500, 1500, "ApplyLoan2"], "isController": false}, {"data": [0.9801587301587301, 500, 1500, "RegisterCustomer3"], "isController": false}, {"data": [0.996031746031746, 500, 1500, "RegisterCustomer2"], "isController": false}, {"data": [1.0, 500, 1500, "RegisterCustomer1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3024, 0, 0.0, 120.0406746031745, 1, 645, 102.0, 286.0, 361.0, 473.0, 684.6275752773375, 211.94037242472268, 220.4647880348653], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["UpdateUser2", 252, 0, 0.0, 103.968253968254, 1, 513, 81.5, 263.0, 344.44999999999993, 458.49999999999994, 60.33038065597319, 10.781698886760834, 26.689123473785017], "isController": false}, {"data": ["Loginuser1", 252, 0, 0.0, 150.54761904761912, 1, 633, 135.0, 303.40000000000003, 372.09999999999997, 519.3599999999999, 60.810810810810814, 10.689400337837837, 12.767894847972972], "isController": false}, {"data": ["UpdateUser3", 252, 0, 0.0, 77.32539682539692, 1, 628, 9.0, 232.0, 276.35, 409.35, 60.30150753768844, 10.953203517587939, 26.617462311557787], "isController": false}, {"data": ["Loginuser2", 252, 0, 0.0, 75.69841269841271, 1, 523, 10.0, 210.00000000000017, 283.2499999999999, 430.35, 61.224489795918366, 10.642538265306124, 12.854751275510205], "isController": false}, {"data": ["Loginuser3", 252, 0, 0.0, 81.80158730158725, 1, 431, 23.5, 223.70000000000002, 304.15, 413.40999999999997, 60.854865974402315, 10.87543014972229, 12.717716131369235], "isController": false}, {"data": ["UpdateUser1", 252, 0, 0.0, 103.57142857142854, 1, 551, 50.0, 263.40000000000003, 373.49999999999994, 542.94, 60.417166147206906, 12.685244845360824, 26.72751588348118], "isController": false}, {"data": ["ApplyLoan1", 504, 0, 0.0, 123.94642857142846, 3, 505, 118.0, 274.5, 327.5, 464.4499999999999, 119.6865352647827, 22.265903289004985, 36.05790637615768], "isController": false}, {"data": ["ApplyLoan2", 252, 0, 0.0, 121.54761904761895, 3, 462, 104.5, 274.2000000000001, 349.15, 439.23, 60.359281437125745, 10.374251497005988, 18.213884730538922], "isController": false}, {"data": ["RegisterCustomer3", 252, 0, 0.0, 256.2896825396824, 35, 645, 231.0, 437.40000000000003, 487.7, 628.23, 60.3448275862069, 101.83189655172413, 7.307381465517241], "isController": false}, {"data": ["RegisterCustomer2", 252, 0, 0.0, 98.31349206349208, 1, 525, 57.0, 262.70000000000005, 304.8499999999999, 491.37999999999994, 64.49961607371385, 12.408617545431277, 28.53352156385974], "isController": false}, {"data": ["RegisterCustomer1", 252, 0, 0.0, 123.53174603174604, 1, 484, 105.0, 292.80000000000007, 375.09999999999997, 454.28999999999996, 63.49206349206349, 12.214781746031747, 28.025793650793652], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3024, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
